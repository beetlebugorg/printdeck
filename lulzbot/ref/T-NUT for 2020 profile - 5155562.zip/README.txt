T-NUT for 2020 profile by nisi1t on Thingiverse: https://www.thingiverse.com/thing:5155562

Summary:
3D printed T-NUT for 2020 aluminium T-Slot or V- slot using a M3 nut and screw0.2 or 0.3mm layer height,100% infillCheck more of my creations:GENERIC CABLE CHAIN FOR 3D PRINTERS, CNC AND LASER ENGRAVERS -https://cults3d.com/en/3d-model/tool/generic-cable-chain-for-3d-printers-cnc-and-laser-engravers